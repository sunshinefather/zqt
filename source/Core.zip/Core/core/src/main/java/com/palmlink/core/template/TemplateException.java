package com.palmlink.core.template;

/**
 * @author Shihai.Fu
 */
public class TemplateException extends RuntimeException {
    public TemplateException(Throwable cause) {
        super(cause);
    }
}
