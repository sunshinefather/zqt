package com.palmlink.core.util;

/**
 * @author Shihai.Fu
 */
public final class RuntimeIOException extends RuntimeException {
    public RuntimeIOException(Throwable cause) {
        super(cause);
    }
}
