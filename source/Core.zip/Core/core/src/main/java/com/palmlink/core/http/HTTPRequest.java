package com.palmlink.core.http;

import org.apache.http.client.methods.HttpRequestBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * Common http request encapsulation
 * 
 * @author Shihai.Fu
 */
public abstract class HTTPRequest {

    protected final Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * url of this request
     */
    protected final String url;

    /**
     * headers of this request
     */
    private final HTTPHeaders headers = new HTTPHeaders();

    protected HTTPRequest(String url) {
        this.url = url;
    }

    /**
     * add header
     * 
     * @param name
     * @param value
     */
    public void addHeader(String name, String value) {
        headers.add(name, value);
    }

    /**
     * set accept contectType
     * 
     * @param contentType
     */
    public void setAccept(String contentType) {
        headers.add(HTTPConstants.HEADER_ACCEPT, contentType);
    }

    /**
     * create HttpRequestBase instance, and initialize with headers
     * 
     * @throws IOException
     */
    HttpRequestBase create() throws IOException {
        HttpRequestBase request = createRequest();
        headers.putHeaders(request);
        return request;
    }

    /**
     * log the request
     */
    void logRequest() {
        logger.debug("====== http request begin ======");
        headers.log();
        logRequestParams();
        logger.debug("====== http request end ======");
    }

    /**
     * sub class should implement this method to complete the request creation
     * 
     * @throws IOException
     */
    abstract HttpRequestBase createRequest() throws IOException;

    /**
     * sub class should implements this method to complete logging the request
     * parameters
     */
    protected abstract void logRequestParams();
}
