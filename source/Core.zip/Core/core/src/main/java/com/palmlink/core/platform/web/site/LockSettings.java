package com.palmlink.core.platform.web.site;

public class LockSettings {
    
    private String remoteLockServers;

    public String getRemoteLockServers() {
        return remoteLockServers;
    }

    public void setRemoteLockServers(String remoteLockServers) {
        this.remoteLockServers = remoteLockServers;
    }

}