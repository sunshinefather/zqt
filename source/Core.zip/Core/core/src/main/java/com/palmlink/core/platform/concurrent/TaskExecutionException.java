package com.palmlink.core.platform.concurrent;

/**
 * @author Shihai.Fu
 */
public class TaskExecutionException extends RuntimeException {
    public TaskExecutionException(Throwable cause) {
        super(cause);
    }
}
