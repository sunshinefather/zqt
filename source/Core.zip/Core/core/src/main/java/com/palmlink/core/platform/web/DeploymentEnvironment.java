package com.palmlink.core.platform.web;

public enum DeploymentEnvironment {
    PROD, DEV
}
