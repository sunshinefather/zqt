/**
 * 
 */
package com.palmlink.core;

import org.junit.Test;

/**
 * @author Shihai.Fu
 * 
 */
public class Main {

    @Test
    public void test() {
        
    }
}
