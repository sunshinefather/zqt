package com.palmlink.core.platform.web;

import org.springframework.stereotype.Controller;

/**
 * @author Shihai.Fu
 */
@Controller
public class TestController extends DefaultController {
}
